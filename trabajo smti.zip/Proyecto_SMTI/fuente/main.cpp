#include <iostream>
#include "Sensor.h"
#include "ListaGen.h"
#include "ServidorSockets.h"
#include "ExcepcionesSMTI.h"

int main() {
    std::cout << "==================================================" << std::endl;
    std::cout << " SMTI: SERVIDOR DE TELEMETRIA DISTRIBUIDA (UNIDAD 9)" << std::endl;
    std::cout << "==================================================" << std::endl;

    ListaGen<Sensor*> listaPlanta;   // al salir de main, ~ListaGen() libera todo

    try {
        ServidorSMTI servidor(8080);
        servidor.iniciar();
        servidor.atenderCliente(listaPlanta);

        std::cout << "\n--- PROCESAMIENTO POLIMORFICO DE TELEMETRIA ---" << std::endl;
        listaPlanta.procesarTodo();

        std::cout << "\nSensores almacenados: " << listaPlanta.tamano() << std::endl;
        Sensor* s = listaPlanta.buscarPorId(102);
        if (s != nullptr) std::cout << "Busqueda ID 102 -> " << *s << std::endl;
        else              std::cout << "Sensor 102 no encontrado." << std::endl;

    } catch (const std::exception& e) {
        std::cerr << "[EXCEPCION GRAVE SMTI] " << e.what() << std::endl;
        return 1;
    }
    return 0;
}
