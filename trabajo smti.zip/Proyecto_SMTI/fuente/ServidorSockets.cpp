#include "ServidorSockets.h"
#include "ExcepcionesSMTI.h"
#include "SensorTemperatura.h"
#include "SensorPresion.h"
#include "SensorCaudal.h"
#include <cstring>
#include <string>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

ServidorSMTI::ServidorSMTI(int p) : server_fd(-1), puerto(p) {}

ServidorSMTI::~ServidorSMTI() {
    if (server_fd >= 0) close(server_fd);
}

void ServidorSMTI::iniciar() {
    // 1. socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0)
        throw ErrorRedSMTI("No se pudo crear el socket.");

    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // 2. direccion
    sockaddr_in addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(puerto);

    // 3. bind
    if (bind(server_fd, (struct sockaddr*)&addr, sizeof(addr)) < 0)
        throw ErrorRedSMTI("bind fallido, el puerto " + std::to_string(puerto) + " esta ocupado.");

    // 4. listen
    if (listen(server_fd, 5) < 0)
        throw ErrorRedSMTI("listen fallido.");

    std::cout << "[SERVIDOR] Escuchando telemetria en puerto " << puerto << "..." << std::endl;
}

// recv puede devolver menos bytes de los pedidos, por eso se repite hasta completar
bool ServidorSMTI::recibirExacto(int fd, void* buf, std::size_t n) {
    char* p = static_cast<char*>(buf);
    std::size_t total = 0;
    while (total < n) {
        ssize_t r = recv(fd, p + total, n - total, 0);
        if (r == 0) return false;                       // el cliente cerro la conexion
        if (r < 0) throw ErrorRedSMTI("fallo en recv().");
        total += r;
    }
    return true;
}

Sensor* ServidorSMTI::crearSensor(const MuestraSensor& m) {
    char tipo[13];
    std::memcpy(tipo, m.tipo, 12);
    tipo[12] = '\0';                                   // seguridad: garantizo el fin de cadena
    std::string t(tipo);
    std::string ubic = "Nodo-" + std::to_string(m.idSensor);

    if (t == "TEMPERATURA") return new SensorTemperatura(m.idSensor, ubic, m.valor);
    if (t == "PRESION")     return new SensorPresion(m.idSensor, ubic, m.valor);
    if (t == "CAUDAL")      return new SensorCaudal(m.idSensor, ubic, m.valor);
    throw ErrorTramaSMTI("tipo de sensor desconocido '" + t + "'.");
}

void ServidorSMTI::atenderCliente(ListaGen<Sensor*>& lista) {
    sockaddr_in cliente;
    socklen_t len = sizeof(cliente);
    int client_fd = accept(server_fd, (struct sockaddr*)&cliente, &len); // bloquea hasta que llegue alguien
    if (client_fd < 0)
        throw ErrorRedSMTI("accept fallido.");
    std::cout << "[SERVIDOR] Cliente conectado." << std::endl;

    MuestraSensor m;
    try {
        while (recibirExacto(client_fd, &m, sizeof(m))) {
            try {
                Sensor* s = crearSensor(m);   // new en el Heap
                lista.insertar(s);
                std::cout << "[SERVIDOR] Muestra recibida del sensor " << m.idSensor << std::endl;
            } catch (const ErrorTramaSMTI& e) {
                // una trama mala NO tumba el servidor: se reporta y se sigue
                std::cerr << "[AVISO] " << e.what() << std::endl;
            }
        }
    } catch (...) {
        close(client_fd);   // si hay error de red, cierro y relanzo
        throw;
    }
    close(client_fd);
    std::cout << "[SERVIDOR] Cliente desconectado." << std::endl;
}
