#ifndef EXCEPCIONESSMTI_H
#define EXCEPCIONESSMTI_H
#include <stdexcept>
#include <string>

// Todas heredan de std::runtime_error, asi main() las atrapa con std::exception&
class ErrorRedSMTI : public std::runtime_error {
public:
    ErrorRedSMTI(const std::string& msg) : std::runtime_error("Error de red: " + msg) {}
};

class ErrorTramaSMTI : public std::runtime_error {
public:
    ErrorTramaSMTI(const std::string& msg) : std::runtime_error("Trama invalida: " + msg) {}
};
#endif
