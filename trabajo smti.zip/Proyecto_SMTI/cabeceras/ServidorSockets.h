#ifndef SERVIDORSOCKETS_H
#define SERVIDORSOCKETS_H
#include <cstddef>
#include "Sensor.h"
#include "ListaGen.h"

// Trama binaria industrial que envian los nodos sensores
struct MuestraSensor {
    int idSensor;
    double valor;
    char tipo[12];   // "TEMPERATURA", "PRESION" o "CAUDAL"
};

class ServidorSMTI {
private:
    int server_fd;
    int puerto;
    bool recibirExacto(int fd, void* buf, std::size_t n); // lee n bytes completos
    Sensor* crearSensor(const MuestraSensor& m);           // fabrica de sensores (new)
public:
    ServidorSMTI(int p = 8080);
    ~ServidorSMTI();
    void iniciar();                                  // socket + bind + listen
    void atenderCliente(ListaGen<Sensor*>& lista);   // accept + recv + insertar
};
#endif
