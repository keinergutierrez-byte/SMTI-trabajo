#ifndef SENSOR_H
#define SENSOR_H
#include <iostream>
#include <string>

// Clase abstracta: tiene un metodo virtual puro, no se puede hacer "new Sensor"
class Sensor {
protected:
    int id;
    std::string ubicacion;
    double lectura;
public:
    Sensor(int _id, const std::string& _ub, double _lect);
    virtual ~Sensor();                 // virtual: para que delete sobre Sensor* llame al destructor del hijo
    int getId() const;
    double getLectura() const;
    virtual void procesarLectura() = 0; // virtual puro
    friend std::ostream& operator<<(std::ostream& os, const Sensor& s);
};
#endif
