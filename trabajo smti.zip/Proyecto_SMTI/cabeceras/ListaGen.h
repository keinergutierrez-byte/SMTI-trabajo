#ifndef LISTAGEN_H
#define LISTAGEN_H
#include <iostream>
#include <stdexcept>

template <typename T>
struct NodoGen {
    T dato;
    NodoGen<T>* siguiente;
    NodoGen(T _d) : dato(_d), siguiente(nullptr) {}
};

// Lista enlazada generica. Se usa con T = puntero (ej: Sensor*)
// porque el destructor hace delete del dato.
template <typename T>
class ListaGen {
private:
    NodoGen<T>* head;
    int tam;

public:
    ListaGen() : head(nullptr), tam(0) {}

    // Prohibimos copiar: si se copiara, dos listas harian delete de los mismos punteros
    ListaGen(const ListaGen&) = delete;
    ListaGen& operator=(const ListaGen&) = delete;

    ~ListaGen() {
        NodoGen<T>* actual = head;
        while (actual != nullptr) {
            NodoGen<T>* aux = actual->siguiente; // guardo el siguiente ANTES de borrar
            delete actual->dato;                 // libera el sensor (llama destructor virtual)
            delete actual;                       // libera el nodo
            actual = aux;
        }
        head = nullptr;
    }

    // Insercion al inicio
    void insertar(T nuevoDato) {
        NodoGen<T>* nuevo = new NodoGen<T>(nuevoDato);
        nuevo->siguiente = head;
        head = nuevo;
        tam++;
    }

    // Recorrido polimorfico (dynamic binding)
    void procesarTodo() {
        NodoGen<T>* actual = head;
        while (actual != nullptr) {
            actual->dato->procesarLectura();
            actual = actual->siguiente;
        }
    }

    // Busqueda por ID (devuelve nullptr si no existe)
    T buscarPorId(int id) const {
        NodoGen<T>* actual = head;
        while (actual != nullptr) {
            if (actual->dato->getId() == id) return actual->dato;
            actual = actual->siguiente;
        }
        return nullptr;
    }

    int tamano() const { return tam; }
};
#endif
