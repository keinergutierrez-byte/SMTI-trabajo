// Cliente de prueba: simula nodos sensores remotos
#include <iostream>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "ServidorSockets.h"

static MuestraSensor crear(int id, double v, const char* tipo) {
    MuestraSensor m;
    std::memset(&m, 0, sizeof(m));
    m.idSensor = id; m.valor = v;
    std::strncpy(m.tipo, tipo, sizeof(m.tipo) - 1);
    return m;
}

int main() {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { std::cerr << "No se pudo crear socket\n"; return 1; }

    sockaddr_in serv;
    std::memset(&serv, 0, sizeof(serv));
    serv.sin_family = AF_INET;
    serv.sin_port = htons(8080);
    inet_pton(AF_INET, "127.0.0.1", &serv.sin_addr);

    if (connect(fd, (struct sockaddr*)&serv, sizeof(serv)) < 0) {
        std::cerr << "No se pudo conectar al servidor\n"; close(fd); return 1;
    }

    MuestraSensor datos[] = {
        crear(101, 92.5, "TEMPERATURA"),
        crear(102, 65.0, "TEMPERATURA"),
        crear(201, 12.3, "PRESION"),
        crear(301,  3.2, "CAUDAL"),
        crear(999,  1.0, "HUMEDAD")    
    };
    for (const MuestraSensor& m : datos)
        send(fd, &m, sizeof(m), 0);

    std::cout << "[CLIENTE] 5 muestras enviadas." << std::endl;
    close(fd);
    return 0;
}
